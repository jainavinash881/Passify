// Chrome Extension API type declarations
/// <reference types="chrome"/>

declare global {
  const chrome: typeof chrome;
}

export {};


